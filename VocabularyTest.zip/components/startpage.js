import React, {useState} from 'react';
import { useFocusEffect } from '@react-navigation/native';
import {Text, View, SafeAreaView, Button, ActivityIndicator, TouchableWithoutFeedback, FlatList} from 'react-native';
import styles from '../styles';

export default function StartPage({route, navigation}) {
   const [isLoading, setLoading] = useState(true);
   const [books, setBooks] = useState([]);
     //uppdaterar sidan varje gång man kommer till den
     useFocusEffect(
       React.useCallback(() => {
     // Om isLoading är sant hämtas data en gång från mitt API som körs lokalt.
     if (isLoading == true) {
         fetch('http://193.10.202.70/WordLearn/api/wordgroups')
         .then(response=> response.json())
         .then(data => {
             console.log(data)
             setLoading(false);
             setBooks(data)
         })
         .catch(error => {
           console.error(error);
         });
     }
   }, [])
   )
   
   return (
   <View style={styles.background}>
     <View style={styles.container}>
       <SafeAreaView style={styles.container}>
        {isLoading == true && <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
           <Text>Vänta medan data laddas ...</Text>
           <ActivityIndicator size="large" color="#aa0707" /></View>}
 
         <FlatList
           data={books}
           renderItem={({item}) => 
           <TouchableWithoutFeedback onPress={() => navigation.navigate('Test', {book: item})}> 
             <Text style = {styles.listTextStyle}>{item.Description}</Text>
           </TouchableWithoutFeedback>          
         }
           keyExtractor={item => item.Id.toString()}
         />
       </SafeAreaView>
     </View>
   </View>
   );

   //  return (
     
   //        <View  style = { styles.container }>
   //           <Button title ='Gör prov' onPress = {() =>  navigation.navigate('Test')} />   
   //           <View style={{padding:5} } />
   //           <Button title ='Visa alla ord' onPress = {() =>  navigation.navigate('AllWords')} />   
   //        </View>
   //       )
}